import { View, Text } from 'react-native'
import React, { useContext, useEffect, useLayoutEffect } from 'react'

import DriverPage from './DriverPage'
import { SafeAreaView } from 'react-native-safe-area-context'
import MainInjury from './MainInjury'
import { AppContext } from './CONSTANTS'
import { registerForPushNotificationsAsync } from '../utils/Utils'

const MainScreen = () => {
    const {userDetails}=useContext(AppContext)

  //   useLayoutEffect(()=>{
  //     navigation.setOptions({
  //         gestureEnabled: false, // disables the swipe gesture
  //       });
  // },[navigation])



  return (
    <SafeAreaView>
            {
         userDetails.type==='Driver'?<DriverPage></DriverPage>:<></>
    }
    {
        userDetails.type==="Patient"?<MainInjury></MainInjury>:<></>
    }
    </SafeAreaView>
    
 
   
  )
}

export default MainScreen