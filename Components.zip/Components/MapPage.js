import { View, Text, StyleSheet } from 'react-native'
import React, { useEffect, useState } from 'react'
import MapView, { Marker,Polyline} from 'react-native-maps';
import * as Location from 'expo-location';

const MapPage = () => {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);

  useEffect(() => {
    console.log('came into useeffect ')
    getLocation()
  }, []);
  const getLocation=async () => {
      
    let { status } = await Location.requestForegroundPermissionsAsync();
    console.log('satus is ',status);
    if (status !== 'granted') {
      setErrorMsg('Permission to access location was denied');
      return;
    }

    try{
      console.log('geeteing locaion ')

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
      console.log('location  in is ',location)

    }catch(e){
      console.log('error in getting location is ',e)
    }

    // let location = await Location.getCurrentPositionAsync({});
    console.log('location is ',location)
  
  }

  let text = 'Waiting..';
  if (errorMsg) {
    text = errorMsg;
  } else if (location) {
    text = JSON.stringify(location);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>{JSON.stringify(location?.coords)}</Text>
      <MapView style={[styles.container]}   >
       {location ? <Marker coordinate={location?.coords} ></Marker>:<></>}

      </MapView>

      
    </View>
  );
}

export default MapPage

const styles = StyleSheet.create({
  container: {
    flex: 1,
  }

});