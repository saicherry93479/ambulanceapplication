import { View, Text } from 'react-native'
import React from 'react'

const DriverPage = () => {
  return (
    <View>
      <Text>DriverPage</Text>
    </View>
  )
}

export default DriverPage