import { View, Text, StyleSheet, Button, TouchableOpacity } from 'react-native'
import React, { useEffect, useRef, useState } from 'react'
import {Camera, CameraType} from 'expo-camera'
import { Image } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { windowHeight, windowWidth } from './CONSTANTS'
import { StatusBar } from 'expo-status-bar'
import { MaterialIcons } from '@expo/vector-icons';
import { Entypo } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import axios from 'axios'


const CameraPage = () => {
    const cameraref=useRef()
    const [hasPermission,setHasPermission]=useState()
    const [photo,setPhoto]=useState()
    const [type,setType]=useState(CameraType.back)

    useEffect(()=>{

        (
            async ()=>{
                const cameraPermission=await Camera.requestCameraPermissionsAsync()
                setHasPermission(cameraPermission.status==="granted")

            }
        )()

    })

    const takePic=async ()=>{
        const options={
            quality:1,
            base64:true,
            exif:false
        }
        const newPhoto=await cameraref.current.takePictureAsync(options)
        console.log("photo is ",Object.keys(newPhoto))
        console.log('photo uri ',newPhoto.uri)
        console.log('width is ',newPhoto.width)
        console.log('hwight is ',newPhoto.height)
        setPhoto(newPhoto)
    }   

   

    if(hasPermission===undefined){
        return <Text>Requesting Permissons....</Text>
    }else if(!hasPermission){
        return <Text>Permissons for camera not granted</Text>
    }

    const continueHandler=async ()=>{
        try{
            const data=await axios.get(`http://localhost:8000/?base=hii`)
            console.log('data retirned is ',data)
        }catch(e){
            console.log('error in continue  is ',e)
        }

    }

  return (
    <SafeAreaView>
        <StatusBar
        animated={true}
        backgroundColor="black"
        barStyle={'light-content'}>

        </StatusBar>
       <View>{
            photo ? <Image style={styles.preview} source={{ uri: photo.uri}} />:
            <Camera style={[styles.container]} ref={cameraref} type={type}>
            </Camera>}
        </View> 
        <View style={[styles.cameraBottom]}>
            {photo?<View style={[styles.camerOptions]}>
            <TouchableOpacity  style={[styles.hideButton]} >

            </TouchableOpacity>
            <TouchableOpacity style={[styles.cameraButton]} onPress={()=>setPhoto(null)}>
                <Entypo name="cross" size={35} color="white"  />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.cameraFlip]} onPress={continueHandler}> 
                <AntDesign name="arrowright" size={24} color="white" />

            </TouchableOpacity>

            </View>:<View style={[styles.camerOptions]}>
                <TouchableOpacity style={[styles.cameraFlip]} onPress={()=>setType(p=>p ===CameraType.front?CameraType.back:CameraType.front)}>
                    <MaterialIcons name="flip-camera-android" size={30} color="white" />
                    
                </TouchableOpacity>
                <TouchableOpacity  style={[styles.cameraButton]} onPress={takePic} >

                </TouchableOpacity>
                <TouchableOpacity  style={[styles.hideButton]} >

                </TouchableOpacity>
                
                </View>}
            
        </View>

    </SafeAreaView>
  )
}

export default CameraPage

const styles=StyleSheet.create({
    container:{
        height:windowHeight*0.8,
        // flexBasis:'70%'
        // flex:1,
        // alignItems:'center',
        // justifyContent:"center"
    },
    buttonContainer:{
        backgroundColor:'#fff',
        alignSelf:'flex-end'
    },
    preview: {
        height:windowHeight*0.8
      },
    cameraBottom:{
        
        backgroundColor:'black',
        height:windowHeight*0.2

    },
    camerOptions:{
        padding:20,
        flexDirection:'row',
        // paddingTop:20,
        alignItems:"center",
        // gap:windowWidth*0.3
        paddingHorizontal:40,
        justifyContent:'space-between'
        // justifyContent:'space-around'

    },
    cameraFlip:{
        backgroundColor:'#8c8b8b',
        padding:10,
        borderRadius:50

    },
    cameraButton:{
        height:70,
        width:70,
        borderColor:'white',
        borderRadius:50,
        borderWidth:4,
        display:'flex',
        justifyContent:'center',
        alignItems:'center'
    },
   
    hideButton:{
        height:40,
        width:40
        
    }

})