import { View, Text, TouchableOpacity, KeyboardAvoidingView, Keyboard } from 'react-native'
import React,{useState,useRef, useContext} from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { TextInput,StyleSheet } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native';
import {  AppContext, windowWidth } from './CONSTANTS';
import { commonStyles } from './CommonStyles';
import { useNavigation } from '@react-navigation/native';
import {FirebaseRecaptchaVerifierModal} from 'expo-firebase-recaptcha'
import { auth, db, firebaseConfig } from '../firebase';
import { signInWithPhoneNumber } from 'firebase/auth';
import OtpScreen from './OtpScreen';
import { doc, getDoc, setDoc } from 'firebase/firestore';
// import { AppContext } from '../App';


const LoginScreen = () => {
  
  const navigation=useNavigation()
  const [otpSent,setOtpSent]=useState(false)
  const recaptchRef=useRef(null)
  const [result,setResult]=useState(null)
  const [otp,setOtp]=useState('')

  const {setUserDetails,token,userDetails,user,number,setNumber}=useContext(AppContext)

  const onChangeNumber=(value)=>{
    setNumber(value)

  }

  const otpHandler=()=>{
    console.log('otp button clicked')
    // navigation.navigate('otp')
    signInWithPhoneNumber(auth,`+91${number}`,recaptchRef.current).then((result)=>{
      console.log('result is ',result)
      setResult(result)
      setOtpSent(true)
 

    }).catch(e=>{
      console.log("unable to send  e is ",e)
    })
    

  }
  const onOtpConfirm=async ()=>{
    result.confirm(otp).then(async (result) => {
      // User signed in successfully.
      const user = result.user;
      console.log('login sucessfull ',user)
      const isUserPresent= await checkUserPresent(user.uid)
      if(isUserPresent.bool){
        console.log('data is ',isUserPresent.userData)
        console.log('userdetails is ',userDetails)
        if(isUserPresent.userData.token!==token){
          const dat={...userDetails,token:token}
         try{
          await setDoc(doc(db,'users',user.uid),dat)
          console.log('sent the data sucessfully updated token ')
         }catch(e){
          console.log('error in updating the token ',e)
         }
        }
        navigation.navigate('mainInjury')
       
        return

      }
      navigation.navigate('userSelect',{userId:user.uid})
      return 



      // ...
    }).catch((error) => {
      // User couldn't sign in (bad verification code?)
      console.log('no failed ',error)
      // ...
    });
    
  }

  const checkUserPresent=async (userId)=>{  
    const ref=doc(db,"users",userId)
    const document = await getDoc(ref)
    if(document.exists()){
      console.log("already in databse present")
      setUserDetails(document.data())
      
      return {bool:true,userData:document.data()}
    }
    console.log("in databse not  present")
    return {bool:false}



  }

  return (
    <SafeAreaView>
      <TouchableWithoutFeedback onPress={()=>Keyboard.dismiss()}>
      {/* <KeyboardAvoidingView behavior="padding"> */}
       {
        otpSent?<OtpScreen setOtpSent={setOtpSent}  setOtp={setOtp} setResult={setResult} otp={otp} onOtpConfirm={onOtpConfirm}></OtpScreen>: <View style={[commonStyles.container]}>
        <View style={commonStyles.loginTop}>
          <Text style={[commonStyles.header]}>Login Account </Text>
          <Text style={[commonStyles.subTag]}>Please provide with 
          a valid phone number</Text>
        </View>

         <View style={[commonStyles.loginBottom]}>
            <View style={[commonStyles.textInput]}>
                <Text>+91</Text>
                <TextInput
                style={[{width:"100%"}]}
                // style={commonStyles.input}
                onChangeText={onChangeNumber}
                value={number}
                placeholder="Please enterphone number"
                keyboardType="numeric"
              />

            </View>
            <TouchableOpacity style={[commonStyles.button]} onPress={otpHandler}>
              <Text style={[commonStyles.buttonText]}>Send Otp</Text>
            </TouchableOpacity>
        </View>

      <FirebaseRecaptchaVerifierModal ref={recaptchRef} firebaseConfig={firebaseConfig}></FirebaseRecaptchaVerifierModal>
        
        
    </View>
       }
        
       
        {/* </KeyboardAvoidingView> */}
        </TouchableWithoutFeedback>
    </SafeAreaView>
    
  )
}


export default LoginScreen